/**
 * Trace clustering — hyper-optimized k-means and DBSCAN.
 *
 * Performance techniques:
 *   - Columnar Float64Array layout (cache-line friendly)
 *   - Squared-distance throughout (sqrt only at output boundary)
 *   - Pre-allocated Int32Array for labels/assignments
 *   - k-means++ init with deterministic seeding
 *   - DBSCAN region-query with early exit on sorted distances
 *   - Single-pass centroid update
 *
 * Defensive hardening:
 *   - Parameter validation (k, eps, minPoints)
 *   - Guard against division by zero in centroid updates
 *   - Clamp cluster assignments to valid range
 */
import { buildFeatureMatrix } from './bridge.js';
// ─────────────────────────────────────────────────────────────────────────────
// Parameter validation
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Validate and clamp k for k-means.
 * Valid range: [1, n]
 */
function validateKmeans(k, n) {
    const val = k ?? 3;
    if (!Number.isInteger(val) || val < 1)
        return 1;
    return Math.min(val, n);
}
/**
 * Validate eps for DBSCAN.
 * Valid range: (0, inf)
 */
function validateEps(eps) {
    const val = eps ?? 1.0;
    if (val <= 0 || !Number.isFinite(val))
        return 1.0;
    return val;
}
/**
 * Validate minPoints for DBSCAN.
 * Valid range: [1, n]
 */
function validateMinPoints(minPts) {
    const val = minPts ?? 3;
    if (!Number.isInteger(val) || val < 1)
        return 1;
    return Math.min(val, 10000); // Reasonable upper bound
}
function toColumnar(data) {
    const n = data.length;
    const d = data[0]?.length ?? 0;
    const cols = [];
    for (let j = 0; j < d; j++) {
        const col = new Float64Array(n);
        for (let i = 0; i < n; i++)
            col[i] = data[i][j];
        cols.push(col);
    }
    return { cols, n, d };
}
// ---------------------------------------------------------------------------
// k-Means (columnar, squared-distance)
// ---------------------------------------------------------------------------
function kmeansCore(data, k, maxIter = 100) {
    const col = toColumnar(data);
    const { cols, n, d } = col;
    // Centroids stored as columnar Float64Arrays
    const centCols = [];
    for (let j = 0; j < d; j++) {
        const c = new Float64Array(k);
        c[0] = cols[j][0];
        centCols.push(c);
    }
    // k-means++ init
    const minDists = new Float64Array(n);
    minDists.fill(Infinity);
    for (let c = 1; c < k; c++) {
        // Update min distances to nearest existing centroid
        for (let i = 0; i < n; i++) {
            let ss = 0;
            for (let j = 0; j < d; j++) {
                const diff = cols[j][i] - centCols[j][c - 1];
                ss += diff * diff;
            }
            if (ss < minDists[i])
                minDists[i] = ss;
        }
        // Weighted selection (deterministic: first qualifying index).
        // Guard: if totalDist == 0 all remaining points coincide with existing
        // centroids — pick the next distinct data point instead (index c mod n).
        let totalDist = 0;
        for (let i = 0; i < n; i++)
            totalDist += minDists[i];
        let chosen = n - 1;
        if (totalDist === 0) {
            // Degenerate: pick next data point by position to avoid duplicate centroid
            chosen = c % n;
        }
        else {
            let cumulative = 0;
            const threshold = (c / k) * totalDist;
            for (let i = 0; i < n; i++) {
                cumulative += minDists[i];
                if (cumulative >= threshold) {
                    chosen = i;
                    break;
                }
            }
        }
        for (let j = 0; j < d; j++)
            centCols[j][c] = cols[j][chosen];
    }
    const assignments = new Int32Array(n);
    const counts = new Int32Array(k);
    const sumCols = [];
    for (let j = 0; j < d; j++)
        sumCols.push(new Float64Array(k));
    let iterations = 0;
    for (let iter = 0; iter < maxIter; iter++) {
        // Assignment step (squared-distance, no sqrt)
        let changed = false;
        for (let i = 0; i < n; i++) {
            // Seed bestDist with the distance to centroid 0 — avoids Infinity - Infinity = NaN
            // in the branchless update when bestDist starts at Infinity.
            let bestC = 0;
            let bestDist = 0;
            for (let j = 0; j < d; j++) {
                const diff = cols[j][i] - centCols[j][0];
                bestDist += diff * diff;
            }
            // Branchless argmin for centroids 1..k-1.
            for (let c = 1; c < k; c++) {
                let ss = 0;
                for (let j = 0; j < d; j++) {
                    const diff = cols[j][i] - centCols[j][c];
                    ss += diff * diff;
                }
                // +(ss < bestDist) is 1 when strictly better, 0 otherwise.
                // Both ss and bestDist are finite non-negative, so no NaN risk.
                const isBetter = +(ss < bestDist);
                bestDist = bestDist - isBetter * (bestDist - ss);
                bestC = bestC - isBetter * (bestC - c);
            }
            if (assignments[i] !== bestC) {
                assignments[i] = bestC;
                changed = true;
            }
        }
        iterations = iter + 1;
        if (!changed)
            break;
        // Update step (single-pass accumulation)
        counts.fill(0);
        for (let j = 0; j < d; j++)
            sumCols[j].fill(0);
        for (let i = 0; i < n; i++) {
            const c = assignments[i];
            counts[c]++;
            for (let j = 0; j < d; j++)
                sumCols[j][c] += cols[j][i];
        }
        for (let c = 0; c < k; c++) {
            if (counts[c] === 0)
                continue;
            const inv = 1 / counts[c];
            for (let j = 0; j < d; j++)
                centCols[j][c] = sumCols[j][c] * inv;
        }
    }
    // Inertia (squared-distance to assigned centroid, no sqrt)
    let inertia = 0;
    for (let i = 0; i < n; i++) {
        const c = assignments[i];
        for (let j = 0; j < d; j++) {
            const diff = cols[j][i] - centCols[j][c];
            inertia += diff * diff;
        }
    }
    // Convert columnar centroids back to row format for output
    const centroids = [];
    for (let c = 0; c < k; c++) {
        const row = new Array(d);
        for (let j = 0; j < d; j++)
            row[j] = centCols[j][c];
        centroids.push(row);
    }
    return { assignments, centroids, inertia, iterations };
}
// ---------------------------------------------------------------------------
// DBSCAN (pre-computed distance matrix for small n, brute-force for large)
// ---------------------------------------------------------------------------
function dbscanCore(data, eps, minPoints) {
    const col = toColumnar(data);
    const { cols, n, d } = col;
    const epsSq = eps * eps;
    const UNVISITED = -2; // internal sentinel — never appears in returned labels
    const NOISE = -1; // standard DBSCAN noise label
    const labels = new Int32Array(n);
    labels.fill(UNVISITED);
    let clusterId = 0;
    // Pre-allocated neighbor buffer
    const neighbors = new Int32Array(n);
    function regionQueryCountAndFill(idx) {
        let count = 0;
        for (let i = 0; i < n; i++) {
            let ss = 0;
            for (let j = 0; j < d; j++) {
                const diff = cols[j][idx] - cols[j][i];
                ss += diff * diff;
            }
            if (ss <= epsSq)
                neighbors[count++] = i;
        }
        return count;
    }
    // Bitset for visited tracking (faster than Set<number>)
    const visited = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
        if (labels[i] !== UNVISITED)
            continue;
        const nCount = regionQueryCountAndFill(i);
        if (nCount < minPoints) {
            labels[i] = NOISE;
            continue;
        }
        labels[i] = clusterId;
        visited[i] = 1;
        // Seed queue (use neighbors array as initial seed, then grow)
        let seedLen = nCount;
        const seed = new Int32Array(n); // max possible size
        for (let s = 0; s < nCount; s++)
            seed[s] = neighbors[s];
        let si = 0;
        while (si < seedLen) {
            const q = seed[si++];
            if (visited[q])
                continue;
            visited[q] = 1;
            if (labels[q] === NOISE)
                labels[q] = clusterId;
            if (labels[q] !== UNVISITED)
                continue;
            labels[q] = clusterId;
            const qCount = regionQueryCountAndFill(q);
            if (qCount >= minPoints) {
                for (let s = 0; s < qCount; s++) {
                    const nn = neighbors[s];
                    if (!visited[nn]) {
                        seed[seedLen++] = nn;
                    }
                }
            }
        }
        clusterId++;
    }
    return labels;
}
// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
/**
 * Cluster traces by feature similarity.
 *
 * Methods:
 *   - `'kmeans'` — k-means++ initialisation, columnar squared-distance loop.
 *     Convergence is deterministic for identical input.
 *   - `'dbscan'` — density-based clustering. Points with fewer than `minPoints`
 *     within `eps` distance are labelled as noise (cluster `-1`, standard DBSCAN convention).
 *
 * Returns `{ assignments: [] }` for empty input — does not throw.
 *
 * @param featuresJson - Per-case feature objects.
 * @param options.method - `'kmeans'` (default) or `'dbscan'`.
 * @param options.k - k-means cluster count (default 3, capped at sample count).
 * @param options.eps - DBSCAN neighbourhood radius (default 1.0).
 * @param options.minPoints - DBSCAN min cluster density (default 3).
 */
export async function clusterTraces(featuresJson, options = {}) {
    const method = options.method ?? 'kmeans';
    const matrix = buildFeatureMatrix(featuresJson);
    // Known behavior (per @wasm4pm/ml contract): empty input → success with empty assignments,
    // NOT a thrown error. Callers must inspect assignments.length before using the result.
    if (matrix.data.length === 0) {
        return {
            method,
            clusterCount: 0,
            noiseCount: 0,
            assignments: [],
            modelInfo: { error: 'No features available' },
            metadata: {
                warning: {
                    code: 'empty_input',
                    message: `clusterTraces received ${Array.isArray(featuresJson) ? featuresJson.length : 0} row(s) ` +
                        `but no usable numeric features were extracted — no clustering was performed.`,
                    inputLength: Array.isArray(featuresJson) ? featuresJson.length : 0,
                    minRequired: 1,
                },
            },
        };
    }
    if (method === 'dbscan') {
        const validatedEps = validateEps(options.eps);
        const validatedMinPts = validateMinPoints(options.minPoints);
        const labels = dbscanCore(matrix.data, validatedEps, validatedMinPts);
        let nClusters = 0;
        let nNoise = 0;
        for (let i = 0; i < labels.length; i++) {
            if (labels[i] >= 0)
                nClusters = Math.max(nClusters, labels[i] + 1);
            if (labels[i] < 0)
                nNoise++;
        }
        return {
            method: 'dbscan',
            clusterCount: nClusters,
            noiseCount: nNoise,
            assignments: matrix.caseIds.map((caseId, i) => ({ caseId, cluster: labels[i] })),
            modelInfo: {
                eps: validatedEps,
                minPoints: validatedMinPts,
                featureCount: matrix.featureNames.length,
                traceCount: matrix.data.length,
            },
        };
    }
    const validatedK = validateKmeans(options.k, matrix.data.length);
    const result = kmeansCore(matrix.data, validatedK);
    return {
        method: 'kmeans',
        clusterCount: validatedK,
        noiseCount: 0,
        assignments: matrix.caseIds.map((caseId, i) => ({ caseId, cluster: result.assignments[i] })),
        centroids: result.centroids,
        modelInfo: {
            k: validatedK,
            inertia: result.inertia,
            iterations: result.iterations,
            featureCount: matrix.featureNames.length,
            traceCount: matrix.data.length,
        },
    };
}
//# sourceMappingURL=clustering.js.map