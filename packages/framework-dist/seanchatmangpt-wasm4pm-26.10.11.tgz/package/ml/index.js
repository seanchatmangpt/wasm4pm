/**
 * @wasm4pm/ml
 *
 * Native ML-powered process mining analysis.
 * Classification, clustering, forecasting, anomaly detection, PCA.
 * Zero external ML dependencies — purpose-built for process intelligence.
 */
// Bridge utilities
export { buildFeatureMatrix, encodeLabels, selectTopFeatures, normalizeFeatures } from './bridge.js';
// Feature extractors
export { extractRemainingTimeFeatures } from './features-remaining-time.js';
export { extractDriftFeatures, detectAnomalousDriftWindows } from './features-drift.js';
export { extractOutcomeFeatures, normalizeOutcomeFeatures, assessOutcomeFeatureQuality, OutcomeFeaturesSchema, } from './features-outcome.js';
// Classification & regression (includes runCrossValidation for advanced usage)
export { classifyTraces, regressRemainingTime, runCrossValidation } from './classifiers.js';
// Cross-validation framework
export { stratifiedKFold, holdoutSplit, computeAccuracy, computeRMSE, computeMAE, computeRSquared, kFoldCrossValidation, holdoutValidation, holdoutRegressionValidation, } from './cross-validation.js';
// Clustering
export { clusterTraces } from './clustering.js';
// Forecasting
export { forecastThroughput, forecastSeries, buildThroughputSeries } from './forecasting.js';
// Anomaly detection
export { detectEnhancedAnomalies } from './anomaly.js';
// Dimensionality reduction
export { reduceFeaturesPCA } from './reduction.js';
// Parameter suggestions
export { suggestClusteringK, suggestPCAComponents, suggestAnomalyThreshold, suggestKnnK, suggestDecisionTreeDepth, suggestPolynomialDegree, suggestForecastHorizon, suggestClassificationAlgorithm, detectLogCharacteristics, } from './parameter-suggestions.js';
// Feature quality assessment
export { assessFeatureQuality } from './feature-quality.js';
// Overfitting detection
export { analyzeOverfitting, hasOverfittingConcerns, getOverfittingSeverity, } from './overfitting-detector.js';
// Preprocessing guards (5 critical checks)
export { filterZeroVarianceColumns, imputeMissingValues, capOutliers, scaleFeatures, validateSampleFeatureRatio, preprocessFeatures, } from './preprocessing.js';
// Ensemble voting (deterministic tie-breaking, Rank-1 oracle)
export { deterministic_ensemble_vote, ensemble_vote_with_confidence, verify_voting_determinism, categorize_vote_distribution, } from './ensemble-voting.js';
// Feature importance ranking
export { rankFeatureImportance, computeCorrelationImportance, computeMutualInformationImportance, computePermutationImportance, } from './feature-importance.js';
// Algorithm selection (Tier 3 AUTOML Gap-14)
export { selectAlgorithm, selectClassificationAlgorithm, selectClusteringAlgorithm, selectForecastingAlgorithm, selectRegressionAlgorithm, selectPcaDimensionality, computeMulticollinearity, } from './algorithm-selection.js';
export { recommendAlgorithm, selectBestAlgorithmForTask, } from './algorithm-selector.js';
// Hyperparameter search (Tier 3 AUTOML Gap-15/16)
export { gridSearch, expandGrid, getBestParams, } from './hyperparameter-search.js';
// Bootstrap confidence intervals (Tier 3 AUTOML Gap-17)
export { bootstrapCI, bootstrapRegressionCI, seededRng, accuracy, mae, rmse, f1, } from './confidence-intervals.js';
//# sourceMappingURL=index.js.map